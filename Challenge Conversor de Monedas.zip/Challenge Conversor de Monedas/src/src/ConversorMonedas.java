package ConversorMonedas;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.InputMismatchException;
import java.util.Scanner;

import org.json.JSONObject;

public class ConversorMonedas {

    // API key ya incluida en la URL
    private static final String API_URL = "https://v6.exchangerate-api.com/v6/9882a2896fabfb694d4f5f42/latest/USD";

    public static void main(String[] args) throws IOException, InterruptedException {

        // Configuración del HttpClient
        HttpClient client = HttpClient.newHttpClient();

        // Obtener la moneda de destino del usuario
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese la moneda de destino (ejemplo: EUR): ");
        String monedaDestino = scanner.nextLine().toUpperCase();

        double monto = 0;
        boolean entradaValida = false;

        // Validar la entrada del usuario para el monto
        while (!entradaValida) {
            try {
                System.out.println("Ingrese el monto a convertir desde USD: ");
                monto = scanner.nextDouble();
                entradaValida = true; // Si se ingresa un valor válido, salimos del bucle
            } catch (InputMismatchException e) {
                System.out.println("Por favor, ingrese un número válido.");
                scanner.next(); // Limpiar la entrada inválida
            }
        }

        // Crear la solicitud HTTP
        HttpRequest request = HttpRequest.newBuilder().uri(URI.create(API_URL)).build();

        // Enviar la solicitud y recibir la respuesta
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        // Procesar la respuesta
        if (response.statusCode() == 200) {
            String responseBody = response.body();

            // Parsear el JSON usando org.json.JSONObject
            JSONObject jsonObject = new JSONObject(responseBody);

            // Obtener las tasas de cambio
            JSONObject conversionRates = jsonObject.getJSONObject("conversion_rates");
            double tasaDeCambio = conversionRates.getDouble(monedaDestino);

            // Realizar la conversión
            double montoConvertido = monto * tasaDeCambio;

            // Mostrar el resultado
            System.out.println("Tasa de cambio: " + tasaDeCambio);
            System.out.println(monto + " USD son " + montoConvertido + " " + monedaDestino);

        } else {
            System.out.println("Error en la solicitud: " + response.statusCode());
        }
    }
}
